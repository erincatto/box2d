/*
* Copyright (c) 2009 Erin Catto http://www.gphysics.com
*
* Permission to use, copy, modify, distribute and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies.
* Erin Catto makes no representations about the suitability 
* of this software for any purpose.  
* It is provided "as is" without express or implied warranty.
*/

#include <string.h>
#include "glut.h"

// This program simulates projectile motion for various integrators.

float gravity = 10.0f;
bool advance = false;
const int N = 30;
int count = 0;

struct State
{
	float t, x0, x, v;
};

State stateEE[N+1], stateIE[N+1], stateSE[N+1], stateV[N+1], stateN[N+1];

struct Color
{
	Color(float r, float g, float b) : r(r), g(g), b(b) {}
	float r, g, b;
};

void DrawText(int x, int y, char *string)
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	int w = glutGet(GLUT_WINDOW_WIDTH);
	int h = glutGet(GLUT_WINDOW_HEIGHT);
	gluOrtho2D(0, w, h, 0);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	glColor3f(0.9f, 0.6f, 0.6f);
	glRasterPos2i(x, y);
	int length = (int) strlen(string);
	for (int i = 0; i < length; ++i)
	{
		glutBitmapCharacter(GLUT_BITMAP_9_BY_15, string[i]);
	}

	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}

void DrawPosition(const State* state1, const State* state2, const Color* color)
{
	glColor3f(color->r, color->g, color->b);
	glBegin(GL_LINES);
	glVertex2f(state1->t, state1->x);
	glVertex2f(state2->t, state2->x);
	glEnd();
}

void ExplicitEuler(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	state2->x = state1->x + h * state1->v;
	state2->v = state1->v - h * gravity;
}

void ImplicitEuler(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	state2->v = state1->v - h * gravity;
	state2->x = state1->x + h * state2->v;
}

void SymplecticEuler(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	state2->v = state1->v - h * gravity;
	state2->x = state1->x + h * state2->v;
}

void Newton(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	state2->x = state1->x + h * state1->v - 0.5f * h * h * gravity;
	state2->v = state1->v - h * gravity;
}

void Verlet(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	state2->x = 2.0f * state1->x - state1->x0 - h * h * gravity;
	state2->v = (state2->x - state1->x) / h;
}

void SimulationLoop()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	DrawText(5, 15, "Red: EE, Green: IE/SE/Verlet, Yellow: Newton");
	DrawText(5, 30, "Press: SPACE to advance time, R to reset");

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	if (advance && count < N)
	{
		advance = false;
		++count;
	}

	Color colorEE(1.0f, 0.0f, 0.0f);
	Color colorIE(0.0f, 1.0f, 0.0f);
	Color colorSE(0.0f, 0.0f, 1.0f);
	Color colorV(1.0f, 1.0f, 1.0f);
	Color colorN(1.0f, 1.0f, 0.0f);
	for (int i = 0; i < count; ++i)
	{
		DrawPosition(stateEE + i, stateEE + i + 1, &colorEE);
		DrawPosition(stateIE + i, stateIE + i + 1, &colorIE);
		//DrawPosition(stateSE + i, stateSE + i + 1, &colorSE);
		//DrawPosition(stateV + i, stateV + i + 1, &colorV);
		DrawPosition(stateN + i, stateN + i + 1, &colorN);
	}

	glutSwapBuffers();
}

void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 27:
		exit(0);
		break;

	case ' ':
		advance = true;
		break;

	case 'r':
	case 'R':
		count = 0;
		advance = false;
		break;
	}
}

void Reshape(int width, int height)
{
	if (height == 0)
		height = 1;

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	float ratio = float(width) / float(height);

	float lowerX = -1.0f * ratio;
	float upperX = 3.0f * ratio;
	float lowerY = -5.0f;
	float upperY = 10.0f;

	gluOrtho2D(lowerX, upperX, lowerY, upperY);
}

void Integrate()
{
	float h = 1.0f / 10.0f;

	State state0;
	state0.t = 0.0f;
	state0.v = 10.0f;
	state0.x = 0.0f;

	// This makes the Verlet integrator see the initial velocity.
	state0.x0 = state0.x - h * state0.v;

	stateEE[0] = state0;
	stateIE[0] = state0;
	stateSE[0] = state0;
	stateV[0] = state0;
	stateN[0] = state0;

	for (int i = 0; i < N; ++i)
	{
		ExplicitEuler(stateEE + i + 1, stateEE + i, h);
		ImplicitEuler(stateIE + i + 1, stateIE + i, h);
		SymplecticEuler(stateSE + i + 1, stateSE + i, h);
		Verlet(stateV + i + 1, stateV + i, h);
		Newton(stateN + i + 1, stateN + i, h);
	}
}

int main(int argc, char** argv)
{
	Integrate();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
	glutInitWindowSize(800, 800);
	glutCreateWindow("Projectile Motion");

	glutReshapeFunc(Reshape);
	glutDisplayFunc(SimulationLoop);
	glutKeyboardFunc(Keyboard);
	glutIdleFunc(SimulationLoop);

	glutMainLoop();

	return 0;
}
