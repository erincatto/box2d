Exact Buoyancy for Polyhedra by Erin Catto

This demo requires glut and comes with a Windows implementation.

The project files were created using Microsoft Visual C++ 2005.

The controls are:

ESC - quit
R - drop a raft
N - drop a nonconvex polyhedron
B - drop a boat
left, right - rotate view
