% Character simulation using position solver
% This script may be run in Matlab or Octave
% Copyright 2014 Erin Catto

% character target position
pt = [1 0];

% number of constraints
nc = 2;

% planes
angle = pi/12;
ns = [-sin(angle) -cos(angle); -sin(angle) cos(angle)];
cs = [0 0; 0 0];

% iteration count
maxIter = 20;

% impulse storage
lambdas = zeros(maxIter + 1, nc);
lambda = zeros(1, nc);

% position
p = pt;
ps = zeros(maxIter + 1, 2);
ps(1, :) = p;

% main solver loop
for k = 1:maxIter

	% loop over constraints
	for i = 1:nc
		normal = ns(i, :);
		c = cs(i, :);
		s = dot(p - c, normal);
		separations(k + 1, i) = s;

		if s < 0
			lambda(i) = lambda(i) + s;
			p = p - s * normal;
		end
	end

	lambdas(k + 1, :) = lambda;
	ps(k + 1, :) = p;
end

% plot results
iters = [0:maxIter];
plot(iters, ps)
xlabel('iteration')
ylabel('x and y position')
legend('x', 'y')
title('Character versus 30 degree acute corner')
% print -dsvg Character.svg
