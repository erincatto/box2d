% Circle stack simulation using Sequential Impulses
% This script may be run in Matlab or Octave
% Copyright 2014 Erin Catto

% time step
h = 1/60;

% gravity
g = 10;

% mass of bodies, first body is ground
masses = [0 1 1 1 1];

% inverse masses
invMasses = [0 1/masses(2) 1/masses(3) 1/masses(4) 1/masses(5)];

% body velocities
v = [0 -h*g -h*g -h*g -h*g];

% number of constraints
n = 4;

% initial constraint impulses
lambda = [0 0 0 0];

% iteration count
maxIter = 20;

% impulse storage
lambdas = zeros(maxIter + 1, n);

% main solver loop
for k = 1:maxIter

	% loop over constraints
	for i = 1:n
		indexA = i + 0;
		indexB = i + 1;
		invMassA = invMasses(indexA);
		invMassB = invMasses(indexB);
		effectiveMass = 1 / (invMassA + invMassB);
		vA = v(indexA);
		vB = v(indexB);
		oldImpulse = lambda(i);
		deltaImpulse = -effectiveMass * (vB - vA);
		lambda(i) = oldImpulse + deltaImpulse;
		vA = vA - invMassA * deltaImpulse;
		vB = vB + invMassB * deltaImpulse;
		v(indexA) = vA;
		v(indexB) = vB;
	end

	lambdas(k + 1,:) = lambda;
end

% exact impulse values for comparison
exact1 = h * g * sum(masses(2:5)) * ones(maxIter + 1, 1);
exact2 = h * g * sum(masses(3:5)) * ones(maxIter + 1, 1);
exact3 = h * g * sum(masses(4:5)) * ones(maxIter + 1, 1);
exact4 = h * g * masses(5) * ones(maxIter + 1, 1);
exact = [exact1 exact2 exact3 exact4];

% plot results
iters = [0:maxIter];
%plot(iters, lambdas(:,1), 'r', iters, lambdas(:,2), 'g', iters, exact1, '--r', iters, exact2, '--g')
plot(iters, lambdas, iters, exact, '--')
xlabel('iteration')
ylabel('total impulse')
%legend('lambda1', 'lambda2', 'lambda3', 'lambda4', 'exact1', 'exact2', 'exact3', 'exact4')
legend('lambda1', 'lambda2', 'lambda3', 'lambda4')
title('Stacked Circles: m = 1')

% m = [0 1 1] reaches 95% correct in 5 iterations
% m = [0 2 1] reaches 95% correct in 3 iterations
% m = [0 1 2] reaches 95% correct in 8 iterations
% m = [0 1 10] reaches 95% correct in 33 iterations
